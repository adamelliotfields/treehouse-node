### About this Course

Express is a "Fast, unopinionated, minimalist web framework for node." In this course you'll learn how to build an Express site from scratch!  

### Instructions
1. Download and extract the [zip](https://github.com/adamelliotfields/treehouse-node/raw/master/express-basics/express-basics.zip).
2. Run `npm install` or `yarn install`.
3. Run `npm run start` or `yarn start`.  

### About this Workshop

Learn how Express Middleware works. We'll walk through some simple examples to start. Then we'll create a simple Express app to show middleware in context.  

### Instructions
1. Download and extract the [zip](https://github.com/adamelliotfields/treehouse-node/raw/master/understanding-express-middleware/understanding-express-middleware.zip).
2. Run `npm install` or `yarn install`.
3. Run `npm run start` or `yarn start`.  

import React from 'react';

const Footer = () => (
  <footer className='footer'>
    <div className='container text-center'>
      <span>Adam Fields | 2017</span>
    </div>
  </footer>
);

export default Footer;
